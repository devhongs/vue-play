module.exports = {
  lintOnSave: false,
  // outputDir: 'dist',
  // configureWebpack: config => {
  //   config.output.filename = 'js/app.js';
  // },
  // configureWebpack: config => {
  //   config.output.filename = 'js/app.js';
  // },
}