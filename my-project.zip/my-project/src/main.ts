import Vue from 'vue';
import App from './App.vue';
import VueRouter from 'vue-router'
import 'bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import Menu1 from './page/Menu1.vue';
import Menu2 from './page/Menu2.vue';
import Vuex from 'vuex'

Vue.config.productionTip = false;

Vue.use(VueRouter);

const routes = [
  { path: '/foo', component: Menu1 },
  { path: '/bar', component: Menu2 }
];

const router = new VueRouter({
  mode: 'history',
  routes // `routes: routes`의 줄임
});


//VUEX 사용처리
Vue.use(Vuex)

//VUEX 스토어 생성
const store = new Vuex.Store({
  state: {
      world: '임시 세계'
  },
  mutations: {
      setWorld: function(state, data){
          state.world = data
      }
  },
  actions: {
  },
})

new Vue({
  router,
  store,
  render: (h) => h(App),
}).$mount('#app');
