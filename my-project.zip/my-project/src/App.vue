<template>
  <div id="app">
    <Menu />
    <Content />
    <Footer />
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import HelloWorld from './components/HelloWorld.vue';
import Menu from './components/Menu.vue';
import Content from './components/Content.vue';
import Footer from './components/Footer.vue';

@Component({
  components: {
    HelloWorld,
    Menu,
    Content,
    Footer,
  },
})
export default class App extends Vue {}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}
</style>
